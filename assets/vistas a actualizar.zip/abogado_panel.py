from kivy.uix.screenmanager import Screen
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.label import Label
from kivy.uix.button import Button
from kivy.graphics import Color, RoundedRectangle, Line
from database import get_connection
import session

ESTADOS = ["disponible", "guardia", "ocupado"]

ESTADO_CFG = {
    "disponible": {
        "label": "  DISPONIBLE  ",
        "bg":    (0.10, 0.55, 0.25, 1),
        "text":  (0.85, 1.00, 0.85, 1),
    },
    "guardia": {
        "label": "  EN GUARDIA  ",
        "bg":    (0.65, 0.50, 0.00, 1),
        "text":  (1.00, 0.95, 0.70, 1),
    },
    "ocupado": {
        "label": "  OCUPADO  ",
        "bg":    (0.60, 0.10, 0.10, 1),
        "text":  (1.00, 0.80, 0.80, 1),
    },
}


class AbogadoPanelScreen(Screen):

    def on_enter(self):
        # Muestra nombre del abogado en topbar
        user = session.current_user
        if user:
            self.ids.lbl_nombre_abogado.text = user[1] or user[2]
        self.cargar_datos()
        self._actualizar_btn_estado()

    def _get_estado_actual(self):
        user = session.current_user
        if not user:
            return "disponible"
        conn = get_connection()
        c = conn.cursor()
        c.execute("SELECT estado_abogado FROM users WHERE email=?", (user[2],))
        row = c.fetchone()
        conn.close()
        est = row[0] if row and row[0] else "disponible"
        return est if est in ESTADOS else "disponible"

    def _actualizar_btn_estado(self):
        estado = self._get_estado_actual()
        cfg = ESTADO_CFG[estado]
        self.ids.btn_estado.text = cfg["label"]
        self.ids.btn_estado.background_color = cfg["bg"]
        self.ids.btn_estado.color = cfg["text"]

    def cambiar_estado(self):
        user = session.current_user
        if not user:
            return
        estado_actual = self._get_estado_actual()
        idx = ESTADOS.index(estado_actual) if estado_actual in ESTADOS else 0
        nuevo = ESTADOS[(idx + 1) % len(ESTADOS)]
        conn = get_connection()
        c = conn.cursor()
        c.execute("UPDATE users SET estado_abogado=? WHERE email=?", (nuevo, user[2]))
        conn.commit()
        conn.close()
        print("ESTADO ->", nuevo)
        self._actualizar_btn_estado()

    def cargar_datos(self):
        self.ids.lista_consultas.clear_widgets()
        user = session.current_user
        if not user:
            return
        email = user[2]
        conn = get_connection()
        c = conn.cursor()
        c.execute("SELECT COUNT(*) FROM consultas WHERE abogado=?", (email,))
        total = c.fetchone()[0]
        self.ids.lbl_consultas.text = str(total)
        self.ids.lbl_honorarios.text = f"${total * 1000:,}"

        c.execute("""
            SELECT id, user_email, estado, tipo_servicio
            FROM consultas WHERE abogado=?
            ORDER BY id DESC
        """, (email,))
        consultas = c.fetchall()
        conn.close()

        if not consultas:
            lbl = Label(
                text="No hay consultas aun",
                color=(0.50, 0.55, 0.70, 1),
                size_hint_y=None,
                height=60,
            )
            self.ids.lista_consultas.add_widget(lbl)
            return

        tipo_color = {
            "chat":    (0.20, 0.50, 0.90, 1),
            "video":   (0.30, 0.70, 0.50, 1),
            "urgente": (0.80, 0.25, 0.25, 1),
        }

        for cid, cliente, estado, tipo in consultas:
            row = BoxLayout(
                orientation="horizontal",
                size_hint_y=None,
                height=72,
                spacing=10,
            )
            with row.canvas.before:
                Color(rgba=(0.04, 0.06, 0.22, 1))
                row._bg = RoundedRectangle(pos=row.pos, size=row.size, radius=[10])
            row.bind(pos=lambda w, v: setattr(w._bg, 'pos', v),
                     size=lambda w, v: setattr(w._bg, 'size', v))

            tipo_badge = Label(
                text=(tipo or "?").upper(),
                size_hint_x=0.22,
                bold=True,
                font_size=11,
                color=tipo_color.get(tipo, (0.7, 0.7, 0.7, 1)),
            )

            info = BoxLayout(orientation="vertical", size_hint_x=0.58)
            info.add_widget(Label(
                text=cliente,
                font_size=13,
                bold=True,
                color=(0.90, 0.92, 1.0, 1),
                halign="left",
                text_size=(None, None),
            ))
            info.add_widget(Label(
                text=f"Estado: {estado}",
                font_size=11,
                color=(0.50, 0.55, 0.70, 1),
                halign="left",
                text_size=(None, None),
            ))

            btn_abrir = Button(
                text="Abrir",
                size_hint_x=0.20,
                font_size=12,
                background_color=(0.99, 0.84, 0.00, 1),
                color=(0.00, 0.02, 0.12, 1),
                bold=True,
            )
            btn_abrir.bind(on_release=lambda x, c=cid: self.abrir_chat(c))

            row.add_widget(tipo_badge)
            row.add_widget(info)
            row.add_widget(btn_abrir)
            self.ids.lista_consultas.add_widget(row)

    def abrir_chat(self, consulta_id):
        session.current_consulta_id = consulta_id
        self.manager.current = "chat"

    def ir_perfil(self):
        self.manager.current = "perfil"

    def logout(self):
        session.current_user = None
        self.manager.current = "login"
